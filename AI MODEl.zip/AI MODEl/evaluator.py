from nltk.tokenize import word_tokenize
import string
from nltk.corpus import wordnet
from nltk import download

# Download resources (you can remove after one-time execution)
download('punkt')
download('wordnet')
download('omw-1.4')

def preprocess_text(text):
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))  # Remove punctuation
    tokens = word_tokenize(text)
    return tokens

def get_synonyms(word):
    synonyms = set()
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.add(lemma.name().lower().replace('_', ' '))
    return synonyms

def evaluate_answer(user_answer, question_data):
    answer_tokens = set(preprocess_text(user_answer))

    keyword_list = question_data["keywords"]
    expanded_keywords = set()

    # Expand keywords with synonyms
    for word in keyword_list:
        expanded_keywords.update(get_synonyms(word))
        expanded_keywords.add(word.lower())

    matched_keywords = answer_tokens.intersection(expanded_keywords)
    score = round(len(matched_keywords) / len(keyword_list) * 100, 2)

    return {
        "score": score,
        "matched_keywords": list(matched_keywords)
    }
