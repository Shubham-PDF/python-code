from flask import Flask, render_template, request, redirect, url_for, session
import random
import json
from evaluator import evaluate_answer

app = Flask(__name__)
app.secret_key = 'supersecretkey'

def load_questions():
    with open("questions.json", "r", encoding="utf-8") as f:
        return json.load(f)

questions = load_questions()

@app.route('/', methods=['GET', 'POST'])
def index():
    if 'current' not in session:
        session['current'] = 0
        session['score_sum'] = 0
        session['questions'] = random.sample(questions, 5)

    if request.method == 'POST':
        user_answer = request.form['answer']
        question_data = session['questions'][session['current']]
        result = evaluate_answer(user_answer, question_data)

        session['score_sum'] += result['score']
        session['current'] += 1

        return render_template('index.html', result=result, question=None)

    if session['current'] >= len(session['questions']):
        avg_score = round(session['score_sum'] / len(session['questions']), 2)
        session.clear()
        return render_template('result.html', score=avg_score)

    question_data = session['questions'][session['current']]
    return render_template('index.html', question=question_data['question'], result=None)

@app.route('/restart')
def restart():
    session.clear()
    return redirect(url_for('index'))

if __name__ == "__main__":
    app.run(debug=True)
